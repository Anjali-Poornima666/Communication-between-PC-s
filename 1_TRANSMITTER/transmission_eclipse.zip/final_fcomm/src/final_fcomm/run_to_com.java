package final_fcomm;

import java.io.IOException;

public class run_to_com {
	public void run() {
		try {
			String cmd = "/home/chadalavada/Desktop/Fcomm_ANJALI/";
			String py = "text_read";
			String run = "python " + cmd + py + ".py";
			Process p = Runtime.getRuntime().exec(run);
			p.waitFor();
			//System.out.println("asdsad");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
