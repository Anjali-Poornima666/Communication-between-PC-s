package final_fcomm;

import java.awt.Image;
import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

public class popWindow {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					popWindow window = new popWindow("Communication PC's");
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public popWindow(String message) {
		initialize(message);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String message) {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 645, 466);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.getContentPane().setLayout(null);
		
	    
	    
		JButton btnNewButton = new JButton("1.txt");
		btnNewButton.setForeground(new Color(230, 230, 250));
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 20));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				frame.dispose();
				ViewTransferFinal popUp = new ViewTransferFinal("/home/chadalavada/Desktop/input.txt");
				popUp.setVisible(true,"/home/chadalavada/Desktop/input.txt");
			}
		});
		Image img = new ImageIcon("/home/chadalavada/Desktop/file.png").getImage();
		btnNewButton.setBackground(new Color(51, 102, 153));
		btnNewButton.setBounds(81, 139, 171, 85);
		btnNewButton.setIcon(new ImageIcon(img));
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("2.txt");
		btnNewButton_1.setFont(new Font("Dialog", Font.BOLD, 20));
		btnNewButton_1.setForeground(new Color(230, 230, 250));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				ViewTransferFinal popUp = new ViewTransferFinal("/home/chadalavada/Desktop/input1.txt");
				popUp.setVisible(true,"/home/chadalavada/Desktop/input1.txt");
			}
		});
		Image img1 = new ImageIcon("/home/chadalavada/Desktop/file.png").getImage();
		btnNewButton_1.setBackground(new Color(51, 102, 153));
		btnNewButton_1.setBounds(81, 267, 171, 85);
		btnNewButton_1.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_12 = new JButton("2.txt");
		btnNewButton_12.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.exit(0);
			}
		});
		btnNewButton_12.setFont(new Font("Dialog", Font.BOLD, 20));
		btnNewButton_12.setForeground(new Color(230, 230, 250));
		Image img11 = new ImageIcon("/home/chadalavada/Desktop/a.jpeg").getImage();
		btnNewButton_12.setBackground(new Color(51, 102, 153));
		btnNewButton_12.setBounds(550, 350, 125, 125);
		btnNewButton_12.setIcon(new ImageIcon(img11));
		frame.getContentPane().add(btnNewButton_12);
		
		textField = new JTextField();
		textField.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 20));
		textField.setBounds(101, 62, 424, 40);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnTransferText = new JButton("Transfer text");
		btnTransferText.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String textFieldValue = textField.getText();
				if(textFieldValue.equals(""))
				{
					frame.dispose();
					popWindow win = new popWindow("");
					win.setVisib(true,"    ENTER SOMETHING!!!");
					//JOptionPane.showMessageDialog(null, "ENTER SOMETHING!!!");
				}
				else {
					System.out.println(textFieldValue);
					textField.setText("");
					frame.dispose();
					TranferText win = new TranferText(textFieldValue);
					win.setVisible(true,textFieldValue);
				}
			}
		});
		btnTransferText.setBackground(new Color(255, 255, 255));
		btnTransferText.setBounds(444, 118, 145, 29);
		frame.getContentPane().add(btnTransferText);
		
		JLabel label_1 = new JLabel(message);
		label_1.setFont(new Font("Dialog", Font.ITALIC, 18));
		label_1.setForeground(new Color(255, 255, 255));
		label_1.setBackground(new Color(255, 255, 255));
		label_1.setBounds(170, 16, 329, 20);
		frame.getContentPane().add(label_1);
		
		JButton btnExtracttext = new JButton("EXTRACT_TEXT");
		btnExtracttext.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				run_to_com r = new run_to_com();
				r.run();
				frame.dispose();
				TransferFrame frame1 = new TransferFrame("/home/chadalavada/Desktop/Fcomm_ANJALI/output.txt");
				frame1.setVisible(true,"/home/chadalavada/Desktop/Fcomm_ANJALI/output.txt");
			}
		});
		btnExtracttext.setBounds(359, 225, 171, 85);
		frame.getContentPane().add(btnExtracttext);
		
		JLabel label = new JLabel("");
		Image back = new ImageIcon("/home/chadalavada/Desktop/asdfgh.jpg").getImage();
		label.setIcon(new ImageIcon(back));
		label.setBounds(0, 0, 645, 466);
		frame.getContentPane().add(label);
		
	}

	public void setVisib(boolean b,String message) {
		popWindow window = new popWindow(message);
		window.frame.setVisible(b);
	}
}
