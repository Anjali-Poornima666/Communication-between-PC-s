package final_fcomm;

import java.awt.Desktop;
import java.awt.Image;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

public class ViewTransferFinal {

	private JFrame frame;

	/**


	/**
	 * Create the application.
	 */
	public ViewTransferFinal(String name) {
		initialize(name);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String name) {
		frame = new JFrame();
		frame.setBounds(100, 100, 648, 451);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("");
		Image img = new ImageIcon("/home/chadalavada/Desktop/view.png").getImage();
		btnNewButton.setIcon(new ImageIcon(img));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Desktop.getDesktop().open(new java.io.File(name));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(164, 34, 202, 142);
		frame.getContentPane().add(btnNewButton);
		
		JButton button = new JButton("");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				TransferFrame frame1 = new TransferFrame(name);
				frame1.setVisible(true,name);
			}
		});
		Image img1 = new ImageIcon("/home/chadalavada/Desktop/transfer.png").getImage();
		button.setIcon(new ImageIcon(img1));
		button.setBounds(164, 202, 202, 154);
		frame.getContentPane().add(button);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				popWindow win = new popWindow("Communication between PC's");
				win.setVisib(true,"Communication between PC's");
			}
		});
		btnBack.setBounds(473, 34, 115, 29);
		frame.getContentPane().add(btnBack);
		
		JLabel label = new JLabel("");
		Image back = new ImageIcon("/home/chadalavada/Desktop/asdfgh.jpg").getImage();
		label.setIcon(new ImageIcon(back));
		label.setBounds(0, 0, 655, 466);
		frame.getContentPane().add(label);
	}

	public void setVisible(boolean b,String name) {
		ViewTransferFinal window = new ViewTransferFinal(name);
		window.frame.setVisible(b);
	}

}
