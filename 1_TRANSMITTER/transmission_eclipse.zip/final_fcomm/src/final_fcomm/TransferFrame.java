package final_fcomm;

import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class TransferFrame {

	private JFrame frame;

	/**
	 * Create the application.
	 */
	public TransferFrame(String filename1) {
		initialize(filename1);
	}
	
	private void run() {
		try {
			String cmd = "/home/chadalavada/Desktop/";
			String py = "send_com";
			String run = "python " + cmd + py + ".py";
			Process p = Runtime.getRuntime().exec(run);
			p.waitFor();
			//System.out.println("asdsad");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String filename1) {
		frame = new JFrame();
		frame.setBounds(100, 100, 780, 365);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("PC  1");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Scanner input = null;
					input = new Scanner(new File(filename1));
					File file = new File("/home/chadalavada/Desktop/out.txt");
					if(!file.exists()) {
						
							file.createNewFile();
					}
					PrintWriter pw = new PrintWriter(file);
					pw.println("#####");
					while (input.hasNextLine())
					{
						pw.print("1/");
						pw.println(String.valueOf(input.nextLine()));
					}
					pw.println("1/!!~~");
					pw.close();
					input.close();
					System.out.print("DONE!!!!!");
					run();
				}catch(Exception e1) {
					e1.printStackTrace();
				}
				frame.dispose();
				popWindow win = new popWindow("");
				win.setVisib(true,"        Transferring to PC-1");
			}
		});
		Image img = new ImageIcon("/home/chadalavada/Desktop/comp.png").getImage();
		btnNewButton.setIcon(new ImageIcon(img));
		btnNewButton.setBounds(70, 92, 152, 141);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnPc = new JButton("PC 2");
		btnPc.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Scanner input = null;
					input = new Scanner(new File(filename1));
					File file = new File("/home/chadalavada/Desktop/out.txt");
					if(!file.exists()) {
						
							file.createNewFile();
					}
					PrintWriter pw = new PrintWriter(file);
					pw.println("#####");
					while (input.hasNextLine())
					{
						pw.print("2/");
						pw.println(String.valueOf(input.nextLine()));
					}
					pw.println("2/!!~~");
					pw.close();
					input.close();
					System.out.print("DONE!!!!!");
					run();
				}catch(Exception e1) {
					e1.printStackTrace();
				}
				frame.dispose();
				popWindow win = new popWindow("");
				win.setVisib(true,"        Transferring to PC-2");
			}
		});
		Image img1 = new ImageIcon("/home/chadalavada/Desktop/comp.png").getImage();
		btnPc.setIcon(new ImageIcon(img1));
		btnPc.setBounds(300, 92, 152, 141);
		frame.getContentPane().add(btnPc);
		
		JButton btnAll = new JButton("ALL");
		btnAll.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Scanner input = null;
					input = new Scanner(new File(filename1));
					File file = new File("/home/chadalavada/Desktop/out.txt");
					if(!file.exists()) {
						file.createNewFile();
					}
					PrintWriter pw = new PrintWriter(file);
					pw.println("#####");
					while (input.hasNextLine())
					{
						pw.print("3/");
						pw.println(String.valueOf(input.nextLine()));
					}
					pw.println("3/!!~~");
					pw.close();
					input.close();
					System.out.print("DONE!!!!!");
					run();
				}catch(Exception e1) {
					e1.printStackTrace();
				}
				frame.dispose();
				popWindow win = new popWindow("");
				win.setVisib(true,"        Transferring to all PC's");
			}
		});
		Image img2 = new ImageIcon("/home/chadalavada/Desktop/comps.png").getImage();
		btnAll.setIcon(new ImageIcon(img2));
		btnAll.setBounds(515, 92, 152, 141);
		frame.getContentPane().add(btnAll);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				popWindow win = new popWindow("");
				win.setVisib(true,"Communication between PC's");
			}
		});
		btnBack.setBounds(604, 28, 115, 29);
		frame.getContentPane().add(btnBack);
		
		JLabel label = new JLabel("");
		Image back = new ImageIcon("/home/chadalavada/Desktop/asdfgh.jpg").getImage();
		label.setIcon(new ImageIcon(back));
		label.setBounds(0, 0, 845, 466);
		frame.getContentPane().add(label);
	}

	public void setVisible(boolean b,String filename1) {
		TransferFrame window = new TransferFrame(filename1);
		window.frame.setVisible(b);
	}

}