import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.awt.Toolkit;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class read {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					read window = new read();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public read() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 503, 412);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
		JButton btnNewButton = new JButton("Txt 1");
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\saiteja\\Downloads\\27_edit_text.png"));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					Desktop.getDesktop().open(new java.io.File("C:\\Users\\saiteja\\Desktop\\output1.txt"));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(12, 195, 204, 137);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnText = new JButton("Txt 2");
		btnText.setIcon(new ImageIcon("C:\\Users\\saiteja\\Downloads\\27_edit_text.png"));
		btnText.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Desktop.getDesktop().open(new java.io.File("C:\\Users\\saiteja\\Desktop\\output2.txt"));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnText.setBounds(251, 195, 210, 137);
		frame.getContentPane().add(btnText);
		
		JButton btnNewButton_1 = new JButton("Start recieving");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_1.setFont(new Font("Trebuchet MS", Font.BOLD, 17));
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\saiteja\\Desktop\\zxcv.png"));
		btnNewButton_1.setBounds(86, 23, 314, 124);
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
					String c = textField.getText();
				    String cmd = "C:\\Users\\saiteja\\Desktop\\";
				    String py = "read";
				    String run = "python  " +cmd+ py + ".py " + c;
				    System.out.println(run);
				    try {
						Process p = Runtime.getRuntime().exec(run);
						p.waitFor();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
			}
		});
		frame.getContentPane().add(btnNewButton_1);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setText("1");
		textField.setBounds(23, 35, 38, 29);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
	}
}
